For openening the program make sure that:
1. All libraries and modules in the project are downloaded.
2. Open search_and_visualization.py module